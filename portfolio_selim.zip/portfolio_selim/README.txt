PORTFOLIO SELIM - VERSION CORRIGÉE

1. Dézippe ce dossier.
2. Garde toute l'arborescence telle quelle : css, assets, saes.
3. Ouvre index.html avec un navigateur.
4. Ne déplace pas les fichiers HTML séparément sinon le CSS et les liens ne marcheront plus.
