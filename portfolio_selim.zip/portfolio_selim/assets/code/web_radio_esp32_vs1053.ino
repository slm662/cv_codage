/*******************************************************************
V_PGM_1 - Web radio simple avec ESP32 Feather + VS1053 Music Maker FeatherWing.
Identifiants Wi-Fi masqués volontairement pour une publication sur portfolio.
*********************************************************************/

#include <SPI.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <VS1053.h>

#define VS1053_CS 32
#define VS1053_DCS 33
#define VS1053_DREQ 15

const char *ssid = "POINT_ACCES_MOBILE";
const char *password = "********";

#define BUFFSIZE 64
uint8_t mp3buff[BUFFSIZE];

VS1053 player(VS1053_CS, VS1053_DCS, VS1053_DREQ);
WiFiClient client;

struct Station {
  const char *nom;
  const char *host;
  const char *path;
  uint16_t port;
};

Station stations[] = {
  {"Frequence 3", "ice.stream.frequence3.net", "/frequence3-128.mp3", 80},
  {"Fun Radio", "icecast.funradio.fr", "/fun-1-44-128", 80},
  {"RTL", "icecast.rtl.fr", "/rtl-1-44-128", 80},
  {"RFM", "rfm-live-mp3-128.scdn.arkena.com", "/rfm.mp3", 80},
  {"SomaFM Seventies", "ice4.somafm.com", "/seventies-128-mp3", 80}
};

const int nombreStations = sizeof(stations) / sizeof(stations[0]);
int stationActuelle = 0;
int volume = 95;
unsigned long dernierBilan = 0;
unsigned long octetsRecus = 0;

void afficherAide() {
  Serial.println("Commandes clavier : n station suivante, + volume +, - volume -");
}

void connecterWiFi() {
  Serial.print("Connexion au WiFi : ");
  Serial.println(ssid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi connecte");
  Serial.println(WiFi.localIP());
}

void sauterEntetesHttp() {
  unsigned long debut = millis();
  String ligne = "";
  bool premiereLigne = true;
  while (millis() - debut < 5000) {
    while (client.available()) {
      char c = client.read();
      if (c == '\n') {
        ligne.trim();
        if (premiereLigne) { Serial.println(ligne); premiereLigne = false; }
        if (ligne.length() == 0) { Serial.println("Debut du flux audio"); return; }
        ligne = "";
      } else if (c != '\r') ligne += c;
    }
    delay(1);
  }
}

void connecterStation() {
  Station &s = stations[stationActuelle];
  client.stop();
  Serial.print("Connexion station : ");
  Serial.println(s.nom);
  if (!client.connect(s.host, s.port)) { Serial.println("Connexion impossible"); return; }
  client.print(String("GET ") + s.path + " HTTP/1.1\r\n" +
               "Host: " + s.host + "\r\n" +
               "User-Agent: ESP32-VS1053\r\n" +
               "Icy-MetaData: 0\r\n" +
               "Connection: close\r\n\r\n");
  sauterEntetesHttp();
}

void stationSuivante() {
  stationActuelle = (stationActuelle + 1) % nombreStations;
  connecterStation();
}

void changerVolume(int variation) {
  volume += variation;
  if (volume < 0) volume = 0;
  if (volume > 100) volume = 100;
  player.setVolume(volume);
  Serial.println(volume);
}

void gererClavier() {
  if (!Serial.available()) return;
  char c = Serial.read();
  if (c == 'n') stationSuivante();
  else if (c == '+') changerVolume(1);
  else if (c == '-') changerVolume(-1);
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  afficherAide();
  connecterWiFi();
  SPI.begin();
  player.begin();
  if (player.isChipConnected()) Serial.println("VS1053 detecte correctement");
  else Serial.println("ERREUR : VS1053 non detecte");
  if (player.getChipVersion() == 4) player.loadDefaultVs1053Patches();
  player.switchToMp3Mode();
  player.setVolume(volume);
  connecterStation();
}

void loop() {
  gererClavier();
  if (!client.connected()) { connecterStation(); delay(500); return; }
  if (client.available() > 0) {
    uint8_t bytesread = client.read(mp3buff, BUFFSIZE);
    if (bytesread > 0) { octetsRecus += bytesread; player.playChunk(mp3buff, bytesread); }
  }
  if (millis() - dernierBilan > 5000) {
    dernierBilan = millis();
    Serial.print("Octets audio recus : ");
    Serial.println(octetsRecus);
  }
}
